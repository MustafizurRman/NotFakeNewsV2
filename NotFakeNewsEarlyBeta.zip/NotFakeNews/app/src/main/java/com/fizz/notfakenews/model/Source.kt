package com.fizz.notfakenews.model

data class Source(
    val id: String?,
    val name: String?
)